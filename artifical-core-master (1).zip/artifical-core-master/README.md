# artifical-core
 python library to build mega - software
 this library python is utilizabile to write kernel and operating systems .
 the first version is only for the python 2 .
 This library is based on the Linux kernel is on ubuntu , this library is ststa it has created thanks to the niktorthenat python video lessons
 through django formulation you can run the script on a mini - server , but also thank the OpenJDK team so we have created a fork on github of this software beautiful
