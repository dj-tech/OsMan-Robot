void gestore(int signum)
{...}
